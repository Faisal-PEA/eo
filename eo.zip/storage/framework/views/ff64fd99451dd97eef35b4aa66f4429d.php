

<?php $__env->startSection('title', 'Rincian Pesanan #' . $pesanan->kode_pesanan . ' - SB Admin'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading (Bersih Tanpa Tombol Kanan) -->
<div class="mb-4">
    <h1 class="h3 mb-1 text-gray-800 fw-bold">Detail Pesanan #<?php echo e($pesanan->kode_pesanan); ?></h1>
    <p class="text-muted small mb-0">Rincian operasional acara, status pembayaran, dan data pemesan.</p>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show rounded-3 mb-4 shadow-sm" role="alert">
        <i class="bi bi-check-circle-fill me-2 fs-5"></i><?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- Kolom Kiri: Rincian Acara & Biaya (Gaya SB Admin) -->
    <div class="col-lg-8">
        <!-- Card 1: Informasi Klien & Acara -->
        <div class="card card-sb mb-4">
            <div class="card-header py-3 bg-white border-0 d-flex justify-content-between align-items-center">
                <h6 class="m-0 fw-bold text-primary"><i class="bi bi-info-circle me-1"></i> Informasi Agenda Acara</h6>
                <span class="badge bg-light text-dark border px-3 py-2 text-uppercase fw-bold"><?php echo e($pesanan->status); ?></span>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-sm-6">
                        <small class="text-muted d-block text-uppercase text-xs fw-bold">Nama Klien / Pemesan</small>
                        <span class="fw-bold text-dark fs-6"><?php echo e($pesanan->user->name); ?></span>
                    </div>
                    <div class="col-sm-6">
                        <small class="text-muted d-block text-uppercase text-xs fw-bold">Kontak / WhatsApp</small>
                        <span class="fw-bold text-dark fs-6"><?php echo e($pesanan->user->telepon); ?></span>
                    </div>
                    <div class="col-sm-6">
                        <small class="text-muted d-block text-uppercase text-xs fw-bold">Email Klien</small>
                        <span class="text-dark"><?php echo e($pesanan->user->email); ?></span>
                    </div>
                    <div class="col-sm-6">
                        <small class="text-muted d-block text-uppercase text-xs fw-bold">Tanggal Pelaksanaan Acara</small>
                        <span class="fw-bold text-primary"><?php echo e(date('d F Y', strtotime($pesanan->tanggal_event))); ?></span>
                    </div>
                    <div class="col-sm-6">
                        <small class="text-muted d-block text-uppercase text-xs fw-bold">Paket Pilihan</small>
                        <span class="fw-bold text-dark"><?php echo e($pesanan->paket->nama_paket); ?></span>
                        <span class="badge bg-warning text-dark ms-1"><?php echo e($pesanan->paket->kategori); ?></span>
                    </div>
                    <div class="col-sm-6">
                        <small class="text-muted d-block text-uppercase text-xs fw-bold">Lokasi / Gedung Acara</small>
                        <span class="text-dark"><?php echo e($pesanan->lokasi); ?> (<?php echo e($pesanan->jumlah_tamu); ?> Tamu)</span>
                    </div>
                    <?php if($pesanan->catatan): ?>
                        <div class="col-12 mt-3 pt-3 border-top">
                            <small class="text-muted d-block text-uppercase text-xs fw-bold">Catatan Khusus Klien:</small>
                            <p class="mb-0 text-dark small bg-light p-2 rounded"><?php echo e($pesanan->catatan); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Card 2: Rincian Anggaran / Biaya -->
        <div class="card card-sb mb-4">
            <div class="card-header py-3 bg-white border-0">
                <h6 class="m-0 fw-bold text-primary"><i class="bi bi-receipt me-1"></i> Rincian Anggaran & Add-on</h6>
            </div>
            <div class="card-body p-0">
                <table class="table table-hover align-middle mb-0 small">
                    <thead class="table-light text-xs text-uppercase">
                        <tr>
                            <th class="ps-4">Deskripsi Layanan</th>
                            <th class="text-end pe-4">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="ps-4 fw-bold">Biaya Paket Utama: <?php echo e($pesanan->paket->nama_paket); ?></td>
                            <td class="text-end pe-4 fw-bold">Rp <?php echo e(number_format($pesanan->paket->harga, 0, ',', '.')); ?></td>
                        </tr>
                        <?php $__currentLoopData = $pesanan->pesananAddons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="ps-4 text-muted">+ <?php echo e($item->addon->nama_addon); ?> (<?php echo e($item->addon->kategori); ?>)</td>
                                <td class="text-end pe-4 text-primary">+ Rp <?php echo e(number_format($item->subtotal, 0, ',', '.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot class="table-light">
                        <tr>
                            <th class="ps-4 fs-6">Total Biaya Keseluruhan</th>
                            <th class="text-end pe-4 fs-5 text-primary">Rp <?php echo e(number_format($pesanan->total_harga, 0, ',', '.')); ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>

        <!-- Card 3: Riwayat Bukti Transfer Masuk -->
        <div class="card card-sb mb-4">
            <div class="card-header py-3 bg-white border-0">
                <h6 class="m-0 fw-bold text-primary"><i class="bi bi-cash-coin me-1"></i> Riwayat Pembayaran Masuk</h6>
            </div>
            <div class="card-body p-0">
                <?php if($pesanan->pembayarans->isEmpty()): ?>
                    <div class="text-center py-4 text-muted small">
                        Klien belum mengunggah bukti pembayaran apa pun untuk pesanan ini.
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 small">
                            <thead class="table-light text-xs text-uppercase">
                                <tr>
                                    <th class="ps-4">Waktu</th>
                                    <th>Jenis & Bank</th>
                                    <th>Nominal</th>
                                    <th>Status</th>
                                    <th>Bukti</th>
                                    <th class="text-end pe-4">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pesanan->pembayarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bayar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="ps-4"><?php echo e($bayar->created_at->format('d/m/Y H:i')); ?></td>
                                        <td>
                                            <span class="badge bg-secondary text-uppercase"><?php echo e($bayar->jenis); ?></span>
                                            <div><?php echo e($bayar->metode); ?></div>
                                        </td>
                                        <td class="fw-bold text-success">Rp <?php echo e(number_format($bayar->jumlah, 0, ',', '.')); ?></td>
                                        <td>
                                            <?php if($bayar->status === 'verified'): ?>
                                                <span class="badge bg-success">Terverifikasi</span>
                                            <?php elseif($bayar->status === 'pending'): ?>
                                                <span class="badge bg-warning text-dark">Menunggu</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Ditolak</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(asset('uploads/bukti/' . $bayar->bukti_transfer)); ?>" target="_blank" class="btn btn-outline-primary btn-sm py-0 px-2">
                                                <i class="bi bi-image"></i> Lihat Struk
                                            </a>
                                        </td>
                                        <td class="text-end pe-4">
                                            <?php if($bayar->status === 'pending'): ?>
                                                <div class="d-flex justify-content-end gap-1">
                                                    <form action="<?php echo e(url('/admin/pembayaran/' . $bayar->id . '/verifikasi')); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="status" value="verified">
                                                        <button type="submit" class="btn btn-success btn-sm py-0 px-2" title="Terima">
                                                            <i class="bi bi-check-lg"></i>
                                                        </button>
                                                    </form>
                                                    <form action="<?php echo e(url('/admin/pembayaran/' . $bayar->id . '/verifikasi')); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="status" value="rejected">
                                                        <button type="submit" class="btn btn-danger btn-sm py-0 px-2" title="Tolak">
                                                            <i class="bi bi-x-lg"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-muted small">Selesai</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Kolom Kanan: Panel Kontrol Cepat Ubah Status Acara -->
    <div class="col-lg-4">
        <div class="card card-sb sticky-top" style="top: 90px;">
            <div class="card-header py-3 bg-white border-0">
                <h6 class="m-0 fw-bold text-primary"><i class="bi bi-sliders me-1"></i> Kontrol Progres Acara</h6>
            </div>
            <div class="card-body">
                <p class="text-muted small mb-3">Ubah status tahapan acara ini untuk memperbarui progres di dashboard klien.</p>

                <form action="<?php echo e(url('/admin/pesanan/' . $pesanan->id . '/status')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark">Status Saat Ini:</label>
                        <select name="status" class="form-select rounded-2">
                            <option value="pending" <?php echo e($pesanan->status == 'pending' ? 'selected' : ''); ?>>Pending (Menunggu Bayar)</option>
                            <option value="dp_paid" <?php echo e($pesanan->status == 'dp_paid' ? 'selected' : ''); ?>>DP Paid (DP Terverifikasi)</option>
                            <option value="confirmed" <?php echo e($pesanan->status == 'confirmed' ? 'selected' : ''); ?>>Confirmed (Dikonfirmasi)</option>
                            <option value="preparation" <?php echo e($pesanan->status == 'preparation' ? 'selected' : ''); ?>>Preparation (Dalam Persiapan)</option>
                            <option value="done" <?php echo e($pesanan->status == 'done' ? 'selected' : ''); ?>>Done (Acara Sukses Selesai)</option>
                            <option value="cancelled" <?php echo e($pesanan->status == 'cancelled' ? 'selected' : ''); ?>>Cancelled (Dibatalkan)</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 shadow-sm">
                        <i class="bi bi-check2-circle me-1"></i> Perbarui Status
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\FDX\Kuliah\RINTISAN BISNIS DIGITAL\localhost\eo\resources\views/admin/pesanan_detail.blade.php ENDPATH**/ ?>